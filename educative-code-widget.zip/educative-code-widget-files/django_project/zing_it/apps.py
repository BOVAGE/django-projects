from django.apps import AppConfig


class ZingItConfig(AppConfig):
    name = 'zing_it'
