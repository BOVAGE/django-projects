from django.contrib import admin
from .models import Listings


admin.site.register(Listings)

